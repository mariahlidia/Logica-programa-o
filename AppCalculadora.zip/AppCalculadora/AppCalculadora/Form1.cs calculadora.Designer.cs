﻿namespace AppCalculadora
{
    partial class FrmCalculadora
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lbln1 = new System.Windows.Forms.Label();
            this.Lbln2 = new System.Windows.Forms.Label();
            this.btndivisao = new System.Windows.Forms.Button();
            this.btnSubtracao = new System.Windows.Forms.Button();
            this.btnSoma = new System.Windows.Forms.Button();
            this.btnMultiplicacao = new System.Windows.Forms.Button();
            this.txtN2 = new System.Windows.Forms.TextBox();
            this.txtN1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Lbln1
            // 
            this.Lbln1.AutoSize = true;
            this.Lbln1.Location = new System.Drawing.Point(244, 78);
            this.Lbln1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lbln1.Name = "Lbln1";
            this.Lbln1.Size = new System.Drawing.Size(76, 18);
            this.Lbln1.TabIndex = 0;
            this.Lbln1.Text = "Número 1: ";
            // 
            // Lbln2
            // 
            this.Lbln2.AutoSize = true;
            this.Lbln2.Location = new System.Drawing.Point(244, 182);
            this.Lbln2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lbln2.Name = "Lbln2";
            this.Lbln2.Size = new System.Drawing.Size(76, 18);
            this.Lbln2.TabIndex = 1;
            this.Lbln2.Text = "Número 2: ";
            // 
            // btndivisao
            // 
            this.btndivisao.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btndivisao.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
            this.btndivisao.Location = new System.Drawing.Point(219, 370);
            this.btndivisao.Margin = new System.Windows.Forms.Padding(4);
            this.btndivisao.Name = "btndivisao";
            this.btndivisao.Size = new System.Drawing.Size(55, 50);
            this.btndivisao.TabIndex = 2;
            this.btndivisao.Text = "/";
            this.btndivisao.UseVisualStyleBackColor = false;
            this.btndivisao.Click += new System.EventHandler(this.btndivisao_Click);
            // 
            // btnSubtracao
            // 
            this.btnSubtracao.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btnSubtracao.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnSubtracao.Location = new System.Drawing.Point(296, 290);
            this.btnSubtracao.Margin = new System.Windows.Forms.Padding(4);
            this.btnSubtracao.Name = "btnSubtracao";
            this.btnSubtracao.Size = new System.Drawing.Size(55, 49);
            this.btnSubtracao.TabIndex = 3;
            this.btnSubtracao.Text = "-";
            this.btnSubtracao.UseVisualStyleBackColor = false;
            this.btnSubtracao.Click += new System.EventHandler(this.btnSubtracao_Click);
            // 
            // btnSoma
            // 
            this.btnSoma.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btnSoma.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSoma.Location = new System.Drawing.Point(219, 289);
            this.btnSoma.Margin = new System.Windows.Forms.Padding(4);
            this.btnSoma.Name = "btnSoma";
            this.btnSoma.Size = new System.Drawing.Size(55, 50);
            this.btnSoma.TabIndex = 4;
            this.btnSoma.Text = "+";
            this.btnSoma.UseVisualStyleBackColor = false;
            this.btnSoma.Click += new System.EventHandler(this.btnSoma_Click);
            // 
            // btnMultiplicacao
            // 
            this.btnMultiplicacao.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btnMultiplicacao.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnMultiplicacao.Location = new System.Drawing.Point(297, 370);
            this.btnMultiplicacao.Margin = new System.Windows.Forms.Padding(4);
            this.btnMultiplicacao.Name = "btnMultiplicacao";
            this.btnMultiplicacao.Size = new System.Drawing.Size(54, 50);
            this.btnMultiplicacao.TabIndex = 5;
            this.btnMultiplicacao.Text = "*";
            this.btnMultiplicacao.UseVisualStyleBackColor = false;
            this.btnMultiplicacao.Click += new System.EventHandler(this.btnMultiplicacao_Click);
            // 
            // txtN2
            // 
            this.txtN2.Location = new System.Drawing.Point(219, 224);
            this.txtN2.Margin = new System.Windows.Forms.Padding(4);
            this.txtN2.Name = "txtN2";
            this.txtN2.Size = new System.Drawing.Size(132, 25);
            this.txtN2.TabIndex = 6;
            // 
            // txtN1
            // 
            this.txtN1.Location = new System.Drawing.Point(219, 128);
            this.txtN1.Margin = new System.Windows.Forms.Padding(4);
            this.txtN1.Name = "txtN1";
            this.txtN1.Size = new System.Drawing.Size(132, 25);
            this.txtN1.TabIndex = 7;
            // 
            // FrmCalculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(566, 450);
            this.Controls.Add(this.txtN1);
            this.Controls.Add(this.txtN2);
            this.Controls.Add(this.btnMultiplicacao);
            this.Controls.Add(this.btnSoma);
            this.Controls.Add(this.btnSubtracao);
            this.Controls.Add(this.btndivisao);
            this.Controls.Add(this.Lbln2);
            this.Controls.Add(this.Lbln1);
            this.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmCalculadora";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Lbln1;
        private System.Windows.Forms.Label Lbln2;
        private System.Windows.Forms.Button btndivisao;
        private System.Windows.Forms.Button btnSubtracao;
        private System.Windows.Forms.Button btnSoma;
        private System.Windows.Forms.Button btnMultiplicacao;
        private System.Windows.Forms.TextBox txtN2;
        private System.Windows.Forms.TextBox txtN1;
    }
}

