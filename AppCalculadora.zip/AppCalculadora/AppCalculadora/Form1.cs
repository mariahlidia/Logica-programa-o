﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppCalculadora
{
    public partial class FrmCalculadora : Form
    {
        public FrmCalculadora()
        {
            InitializeComponent();
        }

      

       

        private void btnSubtracao_Click(object sender, EventArgs e)
        { 
            // subtracao

            float numero1 = float.Parse(txtN1.Text);
            float numero2  = float.Parse(txtN2.Text);
            float subtracao; 
                
            // cálculo
             
            subtracao = numero1 - numero2;

            // saida 

            MessageBox.Show("Subtração igual a " + subtracao);

            }

        private void btnSoma_Click(object sender, EventArgs e)
        { // Soma
            float numero1 = float.Parse(txtN1.Text);
            float numero2 = float.Parse(txtN2.Text);
            float soma;

          // Cálculo

            soma = numero1 + numero2;

            // saida 

            MessageBox.Show("Soma igual a " + soma);

        }

        private void btndivisao_Click(object sender, EventArgs e)
        { // Divisão
            float numero1 = float.Parse(txtN1.Text);
            float numero2 = float.Parse(txtN2.Text);
            float divisao;

            // Cálculo

            divisao = numero1 / numero2;


            // saida 

            MessageBox.Show("Divisão igual a " + divisao);




        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {// Multiplicacao
            float numero1 = float.Parse(txtN1.Text);
            float numero2 = float.Parse(txtN2.Text);
            float multiplicacao;

            // Cálculo

            multiplicacao = numero1 * numero2;

            // saida 

            MessageBox.Show("Multiplicação igual a " + multiplicacao);

        }
    }
    }

