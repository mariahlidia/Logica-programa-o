﻿using System;
using System.Windows.Forms;

namespace AppLista03_Logica
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num3 = float.Parse(txtNum3.Text);
            float soma;
            soma = num1 + num3;

            MessageBox.Show("Soma = " + soma);
        }
           



        private void txtNum2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3= float.Parse(txtNum3.Text);
            float media;

            media = (num1 + num2 + num3)/3;
            MessageBox.Show("Media =" + media);
        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);

            float porcentagem1, porcentagem2, porcentagem3;
            porcentagem1 = num1 / (num1 + num2 + num3) * 100;
            MessageBox.Show("Porcentagem =" + porcentagem);
        }

    }
    }
    }
}
